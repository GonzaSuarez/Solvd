package com.solvd.bank.interfaces.calculator;

import com.solvd.bank.paymethods.Currency;

public interface ICalculator {

    double calculate(Currency currency);
}
