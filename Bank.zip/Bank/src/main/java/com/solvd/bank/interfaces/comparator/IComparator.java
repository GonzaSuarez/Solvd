package com.solvd.bank.interfaces.comparator;

public interface IComparator {

    boolean compare(Object o);
}
