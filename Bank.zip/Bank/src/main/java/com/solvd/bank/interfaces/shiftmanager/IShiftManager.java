package com.solvd.bank.interfaces.shiftmanager;

public interface IShiftManager {

    void manageShift();
}
